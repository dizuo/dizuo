#ifndef ARC_H_
#define ARC_H_

class CArc
{

};

#endif