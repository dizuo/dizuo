#ifndef __3DCAMERA__
#define __3DCAMERA__

#include <math.h>
#include "..//Define.h"

/////////////////////////////////////////////////////////////////////////////
// Type Definitions:
//

typedef double	Frustum[6][4];		// Holds The Current Frustum Plane Equations

/////////////////////////////////////////////////////////////////////////////
// C3dCamera

class C3dCamera
{
//Construction
public:
    C3dCamera();
    virtual ~C3dCamera();

	void  ReInit();
//Implimentation
public:
//	virtual void Serialize(CArchive& ar, int iVersion);

	void PositionCamera();
	void ResetView(int w=0, int h=0);
	void GetWorldCoord(int ix, int iy, double fz, DVec3& coord);
	void GetScreenCoord(double wX, double wY, double wZ,
							double& scrX, double& scrY, double& scrZ);

	void GetEyePos(double *x, double *y, double *z);
	void GetLookAtPos(double *x, double *y, double *z);
	void GetUpVector(double *x, double *y, double *z);
	double GetFocalLength();
	void SetFocalLength(double length, BOOL bLookAtPos=TRUE);
	void GetRotationAboutLookAt(double *x, double *y, double *z);
	void GetRotationAboutEye(double *x, double *y, double *z);
	void SetEyePos(double x, double y, double z);
	void SetLookAtPos(double x, double y, double z);
	void SetUpVector(double x, double y, double z);
	void SetRotationAboutLookAt(double x, double y, double z);
	void SetRotationAboutEye(double x, double y, double z);
	void SetFarClipPlane(double fFar);
	void SetNearClipPlane(double fNear);

	void CalculateFocalLength();
	void CalculateYawPitchRoll();
	void CalculateUpVector();
	void FitBounds(double minX, double minY, double minZ, 
		double maxX, double maxY,double maxZ);
	void ExtractFrustum();

	void GetRotationMatrix(DMat4& XformMatrix);
	void GetInvRotationMatrix(DMat4& XformMatrix);

	void GetVectorsForRayTracingCamera(DVec3& eye_loc,
		DVec3& eye_look_at,
		DVec3& eye_y,
		DVec3& eye_x);
//Attributes
protected:

public:
	BOOL			m_bResetClippingPlanes;
	unsigned int	m_iDisplayLists;
	int				m_bPerspective;
	size_t			m_iScreenWidth;
	size_t			m_iScreenHeight;

	double			m_fFovY;		// Y-Axis field of view
	double			m_fAspect;		// width(x) to height(y) aspect
	double			m_fLeft;
	double			m_fRight;
	double			m_fBottom;
	double			m_fTop;
	double			m_fNear;
	double			m_fFar;
	int			    m_iViewport[4];

	DVec3			m_fEyePos;
	DVec3			m_fLookAtPos;
	DVec3			m_fUpVector;

	double			m_fFocalLength;
	double		m_fPitch;				// Rotation about the X-Axis
	double		m_fRoll;				// Rotation about the Y-Axis
	double		m_fYaw;					// Rotation about the Z-Axis
	double		m_dModelViewMatrix[16];
	double		m_dProjectionMatrix[16];
	Frustum			m_fFrustum;

};
/////////////////////////////////////////////////////////////////////////////
#endif

//////