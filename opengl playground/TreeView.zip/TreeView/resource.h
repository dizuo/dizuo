//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TreeView.rc
//
#define IDD_FORMVIEW                    101
#define IDI_APPDEFAULT                  110
#define IDI_FOLDEROPEN                  111
#define IDI_FOLDERCLOSED                112
#define IDR_MENU_TREEVIEW               119
#define IDC_TREE                        1001
#define IDC_EXIT                        1002
#define ID_TREEVIEW_ADDITEM             40002
#define ID_TREEVIEW_REMOVEITEM          40003
#define ID_TREEVIEW_EXPAND              40004

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
