#include <iostream>
#include "ConvexHull3D.h"

using namespace std;

int main()
{
	using namespace ConvexHull;
	ConvexHull3D convexHullTest;

	convexHullTest.ReadVertices();
	convexHullTest.DoubleTriangle();
	convexHullTest.ConstructHull();
	convexHullTest.EdgeOrderOnFaces();
	convexHullTest.Print();

	system("PAUSE");

	return 0;
}
